package br.com.unicuritiba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Questao3Application {

	public static void main(String[] args) {
		SpringApplication.run(Questao3Application.class, args);
	}

}
