package br.com.unicuritiba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Questao3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
